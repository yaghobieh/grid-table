export { GridBody } from './GridBody';
export type { GridBodyProps } from './types';

