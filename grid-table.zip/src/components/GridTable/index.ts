export { GridTable } from './GridTable';
export type { GridTableComponentProps } from './types';

