export { Pagination } from './Pagination';
export type { PaginationProps } from './types';

